# FINAL_QC_REPORT — Phase 9

## Claim stress test

| Claim in manuscript | Status | Evidence |
|---|---|---|
| P is ~constant across architectures (43–49) | Supported (confirmatory) | Table 1, script-cluster bootstrap CIs |
| G scales 27→63→213→2210 with granularity | Supported (confirmatory) | Table 1; F2 Kruskal p=0.005 vs shuffle null |
| Abugida P–G coupling ρ=0.47 | Supported in isolation | Table 2, CI [0.10,0.61], F1 perm p<0.005; survives F3 |
| Cross-class coupling pattern | NOT confirmatory | F2 label-shuffle p=0.154 → reported as exploratory in §4.2 |
| H1/H3 confirmatory coupling | Falsified → reframed | §4.2 states this explicitly |
| Spoken-side escape trade-off | Null (reported) | Table 6, ρ≈0.01/−0.05 |
| Written escape ρ(P,orth wlen)=−0.40 | Supported (secondary) | fam-boot CI [−0.94,−0.11] |
| Granularity recoverable (F1=0.76) | Supported (secondary) | grouped CV; baselines reported |
| Class F1=0.70 > G-stump | NOT an advance | reported as such in §4.5 |

## Protocol compliance audit

- [x] SAP frozen before full analysis (SAP_FROZEN.md, commit 6ef2860);
      amendments logged in docs/PROTOCOL_AMENDMENTS.md
- [x] PRIMARY/SECONDARY/EXPLORATORY separated; coupling pattern explicitly
      downgraded to exploratory after F2 (not relabeled confirmatory)
- [x] No Unicode code-point counts used as grapheme inventories without
      justification (CLDR exemplars + curated counts; limitation stated)
- [x] No silent imputation (family=unknown only for clustering; source
      NaNs preserved in dataset)
- [x] Effect sizes + 95% CIs everywhere; no p-only claims
- [x] Dependence-aware inference (script/family cluster bootstrap, grouped CV)
- [x] Negative controls: F1 (permute P within strata), F2 (shuffle labels +
      permute P), F3 (exclude Latn / Han-derived / singleton scripts)
- [x] Trivial baselines in inverse inference (majority, G-only stump)
- [x] Fixed seeds (20261003), relative paths, acquisition ledger with
      sha256 (data_raw/ACQUISITION_LEDGER.csv)
- [x] Figures/tables numbered by first-citation order, zero orphans
      (asserted in build script), no uncited objects
- [x] DOCX: OMML math pipeline, TNR 12pt body / 10pt captions, no markdown
      artifacts
- [x] Cover letter: first person "I", sole author Onishi Tatsuki
      (Shiga University), no invented coauthors
- [x] No "alien"/Arrival in title; extraterrestrial generalization limited
      to one cautious Discussion sentence about unknown symbolic channels
- [x] No fabricated data; every number traces to tables/*.csv + logs/*.txt
- [x] Manuscript contains no internal repo paths, no priority claims
      ("first/novel" absent)

## Known limitations carried into the manuscript

- CLDR exemplar counts ≠ curated grapheme inventories (stated in §6)
- gran-3 cell thin (n=7); morphosyllabic P ~one family → descriptive only
- Stored-unit bound at granularity 4 is a proxy (stated)
- wordfreq covers only 287 pairs (exact-match only; no fallback)

## Reproduction

```
pip install -r requirements.txt
python code/download_data.py        # raw data + ACQUISITION_LEDGER.csv
python code/build_poc_dataset.py    # data_processed/poc_dataset.csv
python code/full_analysis.py        # P1-P3 + F1/F3
python code/combinatorial_escape.py # S1
python code/simulation.py           # S2
python code/inverse_inference.py    # S3
python code/falsification_f2.py     # F2
python code/build_manuscript_docx.py
```
